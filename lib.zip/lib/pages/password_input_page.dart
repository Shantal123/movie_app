import 'package:flutter/material.dart';

class PasswordsInputPage extends StatelessWidget {
  const PasswordsInputPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text("Password Input Page"),
      ),
    );
  }
}