import 'package:flutter/material.dart';

class CapturaInputPage extends StatelessWidget {
  const CapturaInputPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text("Captura de Valores del Input Page"),
      ),
    );
  }
}